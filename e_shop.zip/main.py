a = {}
print(a.keys())