from django.shortcuts import render, redirect
from store.models.customers import Customer
from django.contrib.auth.hashers import make_password
from django.views import View


class Sign_up(View):
    def get(self, request):
        return render(request,'sign_up.html')

    def post(self, request):
        post_data = request.POST
        first_name = post_data.get('first_name')
        last_name = post_data.get('last_name')
        phone_no = post_data.get('phone_no')
        email_id = post_data.get('email_id')
        password = post_data.get('password')
        error_message = None
        values = {'first_name': first_name,
                  'last_name': last_name,
                  'phone_no': phone_no,
                  'email_id': email_id}

        customer = Customer(first_name=first_name,
                            last_name=last_name,
                            phone_no=phone_no,
                            email_id=email_id,
                            password=password)
        error_message = self.validationcustomer(customer)
        if not error_message:
            customer.password = make_password(customer.password)
            customer.register()
            return redirect('homepage')
        else:
            data = {
                'error': error_message,
                'value': values
            }
            return render(request, 'sign_up.html', data)

    def validationcustomer(self,customer):
        error_message = None
        if (not customer.first_name):
            error_message = 'First name required !!'
        elif len(customer.first_name) < 4:
            error_message = 'First name must be 4 characters long'
        elif (not customer.last_name):
            error_message = 'Last name required !!'
        elif len(customer.last_name) < 4:
            error_message = 'Last name must be 4 characters long'
        elif (not customer.phone_no):
            error_message = 'Phone Number name required !!'
        elif len(customer.phone_no) < 10:
            error_message = 'Phone number is short it contain 10 digit'
        elif (not customer.email_id):
            error_message = 'email address is required !!'
        elif (not customer.password):
            error_message = 'Password is required !!'
        elif len(customer.password) < 6:
            error_message = 'Password must be 8 characters long'
        elif customer.itsExits():
            error_message = 'Email Address or Phone number already exits !!'

        return error_message