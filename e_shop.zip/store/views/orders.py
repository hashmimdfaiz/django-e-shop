from django.shortcuts import render, redirect
from store.middlewares.auth import auth_middleware
from django.utils.decorators import method_decorator
from store.models.orders import Order
from django.views import View


class Orders(View):


    def get(self, request):
        customer = request.session.get('customer')
        orders = Order.get_orders_by_customer(customer)
        print(orders)
        orders = orders.reverse()
        return render(request,'order.html',{'orders':orders})
