from django.db import models

class Customer(models.Model):
    first_name = models.CharField(max_length=20)
    last_name = models.CharField(max_length=20)
    phone_no = models.CharField(max_length=15)
    email_id = models.EmailField()
    password = models.CharField(max_length=500)

    def register(self):
        self.save()

    def itsExits(self):
        if Customer.objects.filter(email_id = self.email_id) or Customer.objects.filter(phone_no = self.phone_no):
            return True
        return False

    @staticmethod
    def get_customer_by_email(email_id):
        try:
            return Customer.objects.get(email_id = email_id)
        except:
            return False
