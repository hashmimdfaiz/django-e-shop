from django.contrib import admin
from django.urls import path
from .views import index, sign_up, login, cart, checkout, orders
from django.conf import settings
from django.conf.urls.static import static
from .views.login import logout
from store.middlewares.auth import auth_middleware
from django.utils.decorators import method_decorator
# from .middlewares.auth import auth_middleware

urlpatterns = [
    path('', index.Index.as_view(), name = 'homepage'),
    path('signup',sign_up.Sign_up.as_view()),
    path('login',login.Login.as_view(), name= 'login'),
    path('logout',logout,name='logout'),
    path('cart',auth_middleware(cart.Cart.as_view()),name='cart'),
    path('check-out',checkout.Checkout.as_view(),name= 'checkout'),
    path('orders',auth_middleware(orders.Orders.as_view()),name = 'orders'),

]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)