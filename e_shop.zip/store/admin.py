from django.contrib import admin
from .models.products import Product
from .models.categories import Category
from  .models.customers import Customer
from  .models.orders import Order
# Register your models here.

class Show_products(admin.ModelAdmin):
    list_display = ['name','price','description','category']

class Show_category(admin.ModelAdmin):
    list_display = ['name']

class Show_customers(admin.ModelAdmin):
    list_display = ['first_name', 'last_name', 'phone_no', 'email_id', 'password']

class Show_order(admin.ModelAdmin):
    list_display = ['product','customer','quantity','price','date']

admin.site.register(Product,Show_products)
admin.site.register(Category,Show_category)
admin.site.register(Customer,Show_customers)
admin.site.register(Order,Show_order)
